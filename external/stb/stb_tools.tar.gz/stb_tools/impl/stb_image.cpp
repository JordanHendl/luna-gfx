/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   stb_image.cpp
 * Author: jhendl
 *
 * Created on April 10, 2021, 4:18 PM
 */

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"